
const board = document.querySelector('.board');
const message = document.querySelector('.message');
const restart = document.querySelector('.restart-button')

function createSquares(){
    for(let i=1;i<=9;i++){
        const square = document.createElement('div');
        square.classList.add('sq');
        square.setAttribute('data-num',i);
        board.appendChild(square);
    }
}
createSquares();

const players = [ 'X','0'];
let currentPlayer = players[0];

message.textContent = `O's Turn`;

const winningPatterns = [
    [1,2,3],
    [4,5,6],
    [7,8,9],
    [1,4,7],
    [2,5,8],
    [3,6,9],
    [1,5,9],
    [3,5,7]
]

for(let i=1;i<=9;i++){
    const currsquare = document.querySelector(`.sq[data-num="${i}"]`)

    currsquare.addEventListener('click',()=>{
        
        if(currsquare.textContent === ''){
            currsquare.textContent = currentPlayer;
        }

           if (checkIfWin(currentPlayer)) {
            alert(`${currentPlayer} wins`);
            return;
        }

        if(currentPlayer=='X'?currentPlayer='O':currentPlayer='X');
        message.textContent= `${currentPlayer}'s Turn`;
        
        
    })
}


function checkIfWin(currentPlayer){
    for(let i=0;i<winningPatterns.length;i++){
       const [a,b,c] = winningPatterns[i];
       const squareA = document.querySelector(`.sq[data-num="${a}"]`).textContent;
       const squareB = document.querySelector(`.sq[data-num="${b}"]`).textContent;
       const squareC = document.querySelector(`.sq[data-num="${c}"]`).textContent;

       if(squareA === currentPlayer && squareB === currentPlayer && squareC === currentPlayer){
        return true;
       }
    }
    return false;
}


restart.addEventListener('click', ()=>{
    for(let i=1;i<9;i++){
        document.querySelector(`.sq[data-num="${i}"]`).textContent = "";
    }
    message.textContent = `X's turn`;
    currentPlayer = players[0];    

})


