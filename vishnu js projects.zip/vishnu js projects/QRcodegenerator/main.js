const qrContainer = document.querySelector('.qr-container');
const qrTextInput = document.querySelector('.qr-text');
const generateQrCodebtn = document.querySelector('.generate-qr-code-btn');
const errorMessageText = document.querySelector('.error-message-text')

generateQrCodebtn.addEventListener('click', ()=>{
    validateInputFeild()
})

function validateInputFeild(){
    console.log(qrTextInput.value);

    if(qrTextInput.value.trim().length >0){
        genarateQRcode();
    }else{
        errorMessageText.textContent = "Please enter a valid text to generate QR code";
    }
}

function generateQrCode(){
    
}