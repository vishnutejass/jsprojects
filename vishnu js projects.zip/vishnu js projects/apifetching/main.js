
const postsListContainer = document.querySelector('.posts-list-container');

// fetch using async await method

async function fetchUsingAsyncAwaitMethod(){
     
    const response = await fetch('https://jsonplaceholder.typicode.com/posts', {
        method: 'GET'
     
    });

    const result = await response.json();
    displayResults(result);
    
    // console.log(result);
}

// fetchUsingAsyncAwaitMethod();



// fetch using FetchMethod

function fetchUsingFetchMethod() {

    const fetchRequest = fetch('https://jsonplaceholder.typicode.com/posts', {
        method: 'GET'

    });
    fetchRequest.then((response) => response.json()) // Parse the JSON from the response
    .then((result) => displayResults(result))  
    .catch((e) => console.log(e));


}

// fetchUsingFetchMethod();


// fetch using XHR

function fetchUsingXHR() {
    const xhr = new XMLHttpRequest();  //create a new XHR request
    xhr.open('GET', 'https://jsonplaceholder.typicode.com/posts'); //then call the open method where u will pass the type of request (get,post) and the url
    xhr.responseType = 'json';
    xhr.send();

    xhr.onload = () => {
        if (xhr.status === 200) {
            displayResults(xhr.response);
            console.log(xhr);


        } else {
            console.log('Some Error occured');
        }

    }
}

function displayResults(posts) {


    postsListContainer.innerHTML = posts.map(postItem => `

        <div class="post-item">
        <h3>${postItem.title}</h3>
        <p>${postItem.body}</p>
        </div>
        `).join('');
}

function helperMethod(method,url){
    const promise = new Promise((resolve,reject)=>{
        const xhr = new XMLHttpRequest();
        xhr.open(method,url);
        xhr.responseType= 'json';
        xhr.send();

        xhr.onload = ()=> {
            if(xhr.status === 200){
               resolve(xhr.response) 
            } else{
                reject(xhr.statusText)
            }
        }
    })
    return promise;
}

async function fetchUsingXHRAndAsyncAwait(){
  const response = await helperMethod('GET','https://jsonplaceholder.typicode.com/posts')
    
  displayResults(response);
  
}

fetchUsingXHRAndAsyncAwait();

// XML is used to store and transport data without any predefined tags or semantics.

// you can use foreach method also
// function displayResults(posts) {
//     let htmlContent = "";

//      posts.forEach(postItem => {
//         htmlContent += `
//         <div class="post-item">
//         <h3>${postItem.title}</h3>
//         <p>${postItem.body}</p>
//         </div>`
//         });
//     postsListContainer.innerHTML = htmlContent;
// }

// fetchUsingXHR();   explaination for fetch using xhr

// posts.map(postItem => ...):

// This creates a new array where each element is a string of HTML.
// For example, if posts has three items, map will create an array with three HTML strings.
// .join(""):

// The join("") method takes this array of strings and combines them into a single string with no separator between them.
// If you wanted a separator (like a space or line break), you could provide it inside the join method, like join("\n").
// innerHTML:

// The resulting string from join is then assigned to postsListContainer.innerHTML, which updates the DOM to display the HTML content.
// So, using map in this way leverages its ability to return a transformed array, which you can then directly convert into a single string suitable for innerHTML.


