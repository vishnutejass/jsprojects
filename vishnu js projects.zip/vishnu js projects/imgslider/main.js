const slider = document.querySelector('.slider');
const dotsContainer = document.querySelector('.dots-container');
async function fetchListOfImages(){
   try{
      const response = await fetch('https://picsum.photos/v2/list?page=1&limit=5',{
        method: 'GET'
      })

      const ImagesList = await response.json();

      if(ImagesList && ImagesList.length >0 ) displayImages(ImagesList);

      console.log(ImagesList);

   } catch(error){
    console.error(error);
   }
}

function displayImages(getImagesList){
    
    slider.innerHTML = getImagesList.map(item => `
        
        <div class="slide">
        <img src = ${item.download_url} alt=${item.id} />
        </div>
        `).join("");

    dotsContainer.innerHTML = getImagesList.map((item,index) => `
        
       <span class="dot ${index === 0 ? 'active': ''}" data-slide = ${index}></span
        `).join("");
    
}

fetchListOfImages();

//slider functionality begins

const slides = document.querySelectorAll('.slide');
const prevBtn = document.querySelector('.prev');
const nextBtn = document.querySelector('.next');
let currentSlide =0;

function handleImageSlider(){

    function activeDot(slide){
     
    }
    function changeCurrentSLide(slides){
        
    }
    nextBtn.addEventListener('click', ()=>{
        currentSlide++;

        if(slides.length -1 < currentSlide){
            currentSlide = 0;
        }
        changeCurrentSLide(currentSlide);
    })
    prevBtn.addEventListener('click', ()=>{

    })

    dotsContainer.addEventListener('click', ()=>{})
}

handleImageSlider();