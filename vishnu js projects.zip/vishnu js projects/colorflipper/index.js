const hexBtn = document.querySelector('.hex-btn');
const hexColorValue = document.querySelector('.hex-color-value');
const hexColorContainer = document.querySelector('.hex-color-container');
const hexCopyBtn = document.querySelector('.hex-copy-color');
const rgbCopyBtn = document.querySelector('.rgb-copy-color');

hexBtn.addEventListener('click',()=>{
    let charSet = '0123456789ABCDEF';
    let hexColorOutput = "";

    for(let i=0;  i<6; ++i){
        hexColorOutput += charSet.charAt(Math.floor(Math.random()*charSet.length));
    }
    hexColorValue.textContent = `#${hexColorOutput}`;
    hexColorContainer.style.backgroundColor = `#${hexColorOutput}`;
    hexBtn.style.color = `#${hexColorOutput}`;
})

const rgbButton = document.querySelector('.rgb-btn');
const getRedInputRange = document.querySelector('#red');
const getGreenInputRange = document.querySelector('#green');
const getBlueInputRange = document.querySelector('#blue');
const rgbColorContainer = document.querySelector('.rgb-color-container');

const rgbColorValue = document.querySelector('.rgb-color-value');

rgbButton.addEventListener('click',()=> {
    let extractRedValue = getRedInputRange.value;
    let extractGreenValue = getGreenInputRange.value;
    let extractBlueValue = getBlueInputRange.value;

    rgbColorValue.textContent = `rgb(${extractRedValue},${extractGreenValue},${extractBlueValue})`;
    rgbColorContainer.style.backgroundColor = `rgb(${extractRedValue},${extractGreenValue},${extractBlueValue})`;
    rgbButton.style.color = `rgb(${extractRedValue}, ${extractBlueValue} ,${extractGreenValue})`;
});

function copyHexColorToClipBoard(){
    console.log(hexColorValue.textContent);
    navigator.clipboard.writeText(hexColorValue.textContent);
    alert('Hex Color is copied to clipboard');

}

hexCopyBtn.addEventListener("click", copyHexColorToClipBoard);

function copyRgbcolorToClipboard(){
   navigator.clipboard.writeText(rgbColorValue.textContent);
   alert('RGB color is copied');
}

rgbCopyBtn.addEventListener("click",copyRgbcolorToClipboard);