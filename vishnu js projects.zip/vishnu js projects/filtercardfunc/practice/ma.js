categories = ['All','Men','Women','Kids'];

contents = [
    {id:'Men', label : 'Men shirt-1'},
    {id:'Men', label : 'Men shirt-2'},
    {id:'Men', label : 'Men shirt-3'},
    {id:'Men', label : 'Men shirt-4'},
    {id:'Men', label : 'Men shirt-5'},
    {id:'Women', label : 'Women shirt-1'},
    {id:'Women', label : 'Women shirt-2'},
    {id:'Women', label : 'Women shirt-3'},
    {id:'Women', label : 'Women shirt-4'},
    {id:'Women', label : 'Women shirt-5'},
    {id:'Kids', label : 'Kids shirt-1'},
    {id:'Kids', label : 'Kids shirt-2'},
    {id:'Kids', label : 'Kids shirt-3'},
    {id:'Kids', label : 'Kids shirt-4'},
    {id:'Kids', label : 'Kids shirt-5'}
];

const filterBtnWrapper =  document.querySelector('.filter-button-wrapper');
const contentWrapper = document.querySelector('.content-wrapper');

function createCategoryBtns(){

categories.forEach(category => {
    const buttonEle = document.createElement('button');
    buttonEle.innerText = category;
    buttonEle.classList.add('filter-button');
    buttonEle.setAttribute('data-filter',category);

    filterBtnWrapper.appendChild(buttonEle);
})
}

function createContentCards(){
    contents.forEach(contentItem =>{
        const singleContentItem = document.createElement('div');
        singleContentItem.classList.add('card',contentItem.id);
        singleContentItem.textContent = contentItem.label;

        contentWrapper.appendChild(singleContentItem);
    })
}


createCategoryBtns();
createContentCards();


const allFilterButtons = document.querySelectorAll('.filter-button');
const allCards = document.querySelectorAll('.card');

console.log(allFilterButtons,allCards);

allFilterButtons.forEach(currBtn =>{
    currBtn.addEventListener('click',()=>{
        const ExtractcurrBtnCategory = currBtn.getAttribute('data-filter');

        filterCardsByCategory(ExtractcurrBtnCategory,allCards);

    })
})

function filterCardsByCategory(ExtractcurrBtnCategory,allCards){
    
    allCards.forEach(Card =>{
        const isshowall =  ExtractcurrBtnCategory.toLowerCase()==='all';
        const currBtnCategory = Card.classList.contains(ExtractcurrBtnCategory);
         
        if(!isshowall && !currBtnCategory){
            Card.classList.add('hide');
        }
        else{
            Card.classList.remove('hide');
        }

    })
    
    

}