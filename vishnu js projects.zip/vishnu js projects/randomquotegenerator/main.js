const quoteWrapper = document.querySelector('.quote-wrapper');


function fetchRandomQuote() {

    fetch('https://jsonplaceholder.typicode.com/todos/1')
    .then(response => response.json())
    .then(result => displayQuote(result))
    .catch((e) => console.log(e));
}

function displayQuote(getQuote){
    console.log(getQuote);
     quoteWrapper.innerHTML = `
     <div class="quote-item>
     <p>${getQuote.author}</p>
     </div>
     `
}

fetchRandomQuote()